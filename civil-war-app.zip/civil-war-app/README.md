# A Nation Divided: Civil War Map Missions

A gamified version of the Esri GeoInquiry "A Nation Divided: the Civil War" for U.S. History,
built on the ArcGIS Maps SDK for JavaScript 4.30 and public ArcGIS Online layers.

## Files
- `index.html` – page structure (header, missions panel, map, modals)
- `styles.css` – all styling
- `app.js` – data (state classification, key battles, milestones), game logic, and map code

Keep the three files in the same folder. Open `index.html` in a browser or upload the folder
to any web server. The page needs internet access to `js.arcgis.com`, `services.arcgis.com`,
`services7.arcgis.com`, and `fonts.googleapis.com`.

## Data
- Battles: `https://services7.arcgis.com/tb6wALqFemkR7LHo/ArcGIS/rest/services/civilwarorg_battles/FeatureServer/0`
- States: `https://services.arcgis.com/P3ePLMYs2RVChkJx/arcgis/rest/services/USA_States_Generalized_Boundaries/FeatureServer/0`

Both URLs are in the `LAYER_URLS` object near the top of `app.js` if you need to swap layers.
